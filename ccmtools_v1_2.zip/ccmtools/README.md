# ccmtools

东方医院重症医学工具箱（Critical Care Medicine Tools）。

- 域名建议：`https://tools.shccm.icu`
- 后端端口：`127.0.0.1:8020`
- systemd 服务：`ccmtools.service`
- 无数据库、无登录、无患者记录保存
- 独立于 XBJ-SIC 中央随机化系统，不使用 `8000` 端口，不修改 `xbj_sic.service`

当前收录 80 个工具，覆盖机械通气、休克/血流动力学、ECMO、AKI/CRRT、感染、凝血、营养、镇痛镇静、酸碱电解质和流程核查。

## 本地运行

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python run_local.py
```

浏览器打开：<http://127.0.0.1:8020>

## GitHub 初始化

```bash
git init
git add .
git commit -m "Initial ccmtools release"
git branch -M main
git remote add origin https://github.com/drliuxb/ccmtools.git
git push -u origin main
```


## v1.2 guideline update
- Updated Surviving Sepsis Campaign references from 2021 to 2026.
- Rewrote the sepsis/septic shock initial management checklist according to SSC 2026 principles.
