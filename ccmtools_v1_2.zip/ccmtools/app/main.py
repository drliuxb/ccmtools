
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from dataclasses import dataclass
from typing import Dict, Any
import math
from .tools_data import TOOLS

APP_TITLE = "东方医院重症医学工具箱"
DEPARTMENT = "同济大学附属东方医院重症医学科"
VERSION = "v1.1.0"

app = FastAPI(title=APP_TITLE, version=VERSION)
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")
TOOLS_BY_SLUG = {t['slug']: t for t in TOOLS}
CATEGORIES = []
for t in TOOLS:
    if t['category'] not in CATEGORIES:
        CATEGORIES.append(t['category'])

def fval(data, name, default=0.0):
    try:
        v = data.get(name, default)
        if v in (None, ""):
            return float(default)
        return float(v)
    except Exception:
        return float(default)

def sval(data, name, default=''):
    v = data.get(name, default)
    return default if v is None else str(v)

def checked(data, name):
    return name in data and data.get(name) not in ('', '0', 'false', 'False', None)

def r(x, nd=2):
    try:
        return round(float(x), nd)
    except Exception:
        return x

def pct(x):
    return f"{r(x,1)}%"

def safe_div(a,b):
    return a/b if b not in (0, None) else float('nan')

def interp_level(value, thresholds):
    # thresholds list: (condition, text)
    for cond, txt in thresholds:
        if cond(value): return txt
    return "需结合临床判断"

def checklist_result(tool, data):
    total = sum(1 for f in tool['fields'] if f.get('kind') == 'checkbox')
    done = sum(1 for f in tool['fields'] if f.get('kind') == 'checkbox' and checked(data, f['name']))
    extra = []
    # include notable numeric fields
    for f in tool['fields']:
        if f.get('kind') == 'number' and f.get('name') in data:
            extra.append(f"{f['label']}: {data.get(f['name'])}")
    return {
        'score': f"{done}/{total} 项已完成" if total else "已记录",
        'risk_level': '完成度高' if total and done/total >= .8 else ('仍有关键项目需确认' if total else ''),
        'interpretation': '该工具是流程核查卡，用于减少遗漏。未勾选项目不一定代表禁忌，但应在床旁交接或操作前重新确认。' + ("；" + "；".join(extra) if extra else ''),
        'details': {'已完成项目': done, '总项目': total, '完成率': pct(done/total*100) if total else 'NA'}
    }

def calculate(slug: str, data: Dict[str, Any]):
    tool = TOOLS_BY_SLUG[slug]
    calc = tool['calc']
    details = {}
    score = ''
    risk = ''
    interp = ''
    caution = ''
    if calc == 'checklist':
        return checklist_result(tool, data)
    if calc == 'lpv':
        h=fval(data,'height',170); sex=sval(data,'sex','male'); vt=fval(data,'vt_set',420); pplat=fval(data,'pplat',25); peep=fval(data,'peep',8)
        pbw=(50 if sex=='male' else 45.5)+0.91*(h-152.4)
        dp=pplat-peep
        score=f"PBW {r(pbw,1)} kg；6 mL/kg {r(pbw*6,0)} mL"
        risk='平台压≤30且驱动压较低时更符合肺保护策略' if pplat<=30 and dp<=15 else '平台压或驱动压偏高，需结合病情优化通气策略'
        details={'4 mL/kg':r(pbw*4,0),'6 mL/kg':r(pbw*6,0),'8 mL/kg':r(pbw*8,0),'当前 VT mL/kg PBW':r(vt/pbw,1),'平台压':pplat,'驱动压':dp}
        interp='保护性通气通常以 PBW 而非实际体重计算潮气量。ARDS 患者常以约 6 mL/kg PBW 为初始目标，并关注平台压和驱动压。'
    elif calc == 'mech_power':
        vt=fval(data,'vt',420)/1000; rr=fval(data,'rr',20); peep=fval(data,'peep',8); pplat=fval(data,'pplat',25); ppeak=fval(data,'ppeak',30)
        dp=pplat-peep; cs=vt*1000/dp if dp>0 else float('nan'); mp=0.098*rr*vt*(ppeak-0.5*dp)
        score=f"驱动压 {r(dp,1)} cmH₂O；机械功 {r(mp,2)} J/min"
        risk='驱动压偏高' if dp>15 else '驱动压未见明显升高'
        details={'静态顺应性 mL/cmH₂O':r(cs,1),'简化机械功 J/min':r(mp,2),'峰-平台压差':r(ppeak-pplat,1)}
        interp='机械功是潮气量、压力、PEEP和呼吸频率共同作用的负荷指标；不同公式适用条件不同，本工具为容量控制通气下的简化估算。'
    elif calc == 'peep_table':
        fio2=fval(data,'fio2',0.6); table=sval(data,'table','low')
        low=[(.3,'5'),(.4,'5–8'),(.5,'8–10'),(.6,'10'),(.7,'10–14'),(.8,'14'),(.9,'14–18'),(1.0,'18–24')]
        high=[(.3,'5'),(.4,'8–14'),(.5,'14–16'),(.6,'16–18'),(.7,'18'),(.8,'20'),(.9,'22'),(1.0,'22–24')]
        arr=high if table=='high' else low
        peep=arr[-1][1]
        for th,val in arr:
            if fio2<=th+1e-9: peep=val; break
        score=f"参考 PEEP：{peep} cmH₂O"
        risk='High PEEP 表通常用于更重氧合障碍或可复张性较高者，需关注循环影响。' if table=='high' else 'Low PEEP 表为常用起始参考。'
        details={'FiO₂':fio2,'表格': 'High PEEP' if table=='high' else 'Low PEEP'}
        interp='该表为ARDSNet协议化氧合支持参考，PEEP最终应结合氧合、平台压、驱动压、血压和右心负荷调整。'
    elif calc == 'oxygenation':
        pao2=fval(data,'pao2',80); fio2=fval(data,'fio2',0.5); maw=fval(data,'map_aw',15)
        pf=pao2/fio2 if fio2>0 else float('nan'); oi=fio2*maw*100/pao2 if pao2>0 else float('nan')
        if pf<=100: sev='重度氧合障碍/ARDS氧合标准'
        elif pf<=200: sev='中度氧合障碍/ARDS氧合标准'
        elif pf<=300: sev='轻度氧合障碍/ARDS氧合标准'
        else: sev='未达到ARDS氧合阈值（需结合PEEP/影像/病因）'
        score=f"P/F {r(pf,1)}；OI {r(oi,2)}"
        risk=sev; details={'P/F ratio':r(pf,1),'Oxygenation Index':r(oi,2)}
        interp='P/F ratio用于ARDS氧合分级；OI纳入平均气道压，更能反映为达到氧合所付出的通气压力代价。'
    elif calc == 'rox_trend':
        vals=[]
        for t in ['2','6','12']:
            spo2=fval(data,f'spo2_{t}',95); fio2=fval(data,f'fio2_{t}',0.5); rr=fval(data,f'rr_{t}',24)
            rox=(spo2/fio2)/rr if fio2>0 and rr>0 else float('nan')
            vals.append((t,rox))
        score='；'.join([f"{t}h ROX {r(v,2)}" for t,v in vals])
        last=vals[-1][1]
        risk='12h ROX <3.85，需高度警惕HFNC失败/插管延迟' if last<3.85 else '12h ROX未低于常用高危阈值，仍需看趋势和呼吸功'
        details={f'{t}h ROX':r(v,2) for t,v in vals}
        interp='ROX越低或随时间下降，越提示HFNC失败风险。需结合呼吸功、意识、血流动力学和氧合目标。'
    elif calc == 'weaning':
        peep=fval(data,'peep',5); fio2=fval(data,'fio2',.4); rsbi=fval(data,'rsbi',80); mip=fval(data,'mip',25)
        ok = peep<=8 and fio2<=0.5 and rsbi<105 and mip>=20 and sval(data,'cough')!='poor' and sval(data,'mental')!='poor' and sval(data,'hemo')=='stable' and sval(data,'secretions')!='high'
        score='可考虑进入SBT评估' if ok else '暂不适合或需先优化后再评估SBT'
        risk='撤机条件较充分' if ok else '存在撤机失败风险因素'
        details={'PEEP':peep,'FiO₂':fio2,'RSBI':rsbi,'MIP绝对值':mip}
        interp='SBT前应确认氧合、通气能力、神志、咳嗽排痰和循环稳定。RSBI只是其中一个指标。'
    elif calc == 'rsbi':
        rr=fval(data,'rr',24); vt=fval(data,'vt',350)/1000; rsbi=rr/vt if vt>0 else float('nan')
        score=f"RSBI {r(rsbi,1)} 次/min/L"; risk='传统阈值支持撤机可能性较高' if rsbi<105 else 'RSBI偏高，撤机失败风险增加'
        details={'RR':rr,'VT L':r(vt,3)}; interp='RSBI <105 常作为支持撤机的参考指标，但应结合SBT耐受性、咳嗽、分泌物和循环状态。'
    elif calc == 'compliance':
        vt=fval(data,'vt',420); pplat=fval(data,'pplat',25); ppeak=fval(data,'ppeak',30); peep=fval(data,'peep',8); flow=fval(data,'flow',60)/60
        cs=vt/(pplat-peep) if pplat>peep else float('nan'); cdyn=vt/(ppeak-peep) if ppeak>peep else float('nan'); res=(ppeak-pplat)/flow if flow>0 else float('nan')
        score=f"Cstat {r(cs,1)}；Cdyn {r(cdyn,1)} mL/cmH₂O"; risk='顺应性降低或气道阻力增高需结合病因判断'
        details={'静态顺应性':r(cs,1),'动态顺应性':r(cdyn,1),'气道阻力 cmH₂O/L/s':r(res,1)}; interp='静态顺应性反映肺/胸壁弹性负荷，动态顺应性还受气道阻力影响。'
    elif calc == 'shock_type':
        ci=fval(data,'ci',2); svr=fval(data,'svr',800); scv=fval(data,'scvo2',65); lac=fval(data,'lactate',3); cvp=fval(data,'cvp',8); echo=sval(data,'echo')
        suggestions=[]
        if ci<2.2 and svr>1200: suggestions.append('心源性或低流量高阻力休克')
        if ci>=2.5 and svr<800: suggestions.append('分布性休克')
        if cvp<6 or echo=='small_lv': suggestions.append('低容量因素')
        if echo=='rv_dilation': suggestions.append('梗阻性/右心衰因素')
        if echo=='tamponade': suggestions.append('心包填塞/梗阻性休克警报')
        if not suggestions: suggestions.append('混合型或需更多数据')
        score='；'.join(suggestions); risk='乳酸升高提示组织灌注不足' if lac>=2 else '乳酸未明显升高'
        details={'CI':ci,'SVR':svr,'ScvO2':scv,'乳酸':lac,'CVP':cvp}; interp='休克常为混合型，工具只根据典型血流动力学和超声线索给出方向性提示。'
    elif calc == 'lactate_clearance':
        a=fval(data,'lac0',4); b=fval(data,'lac1',2.8); cl=(a-b)/a*100 if a>0 else float('nan')
        score=f"乳酸清除率 {r(cl,1)}%"; risk='乳酸下降，复苏反应较好' if cl>=10 else '乳酸清除不足或升高，需重新评估灌注/感染源/代谢原因'
        details={'初始乳酸':a,'复测乳酸':b}; interp='乳酸下降通常提示灌注改善，但肝功能、β受体激动、惊厥等也会影响乳酸。'
    elif calc == 'ned':
        ne=fval(data,'ne'); epi=fval(data,'epi'); dop=fval(data,'dopamine'); phen=fval(data,'phenyl'); vaso=fval(data,'vaso')
        ned=ne+epi+dop/100+phen/10+vaso*2.5
        score=f"Norepinephrine equivalent ≈ {r(ned,3)} μg/kg/min"; risk='血管活性药负荷较高' if ned>=0.3 else '血管活性药负荷中低'
        details={'NE':ne,'Epi':epi,'Dopamine/100':r(dop/100,3),'Phenyl/10':r(phen/10,3),'Vaso*2.5':r(vaso*2.5,3)}; interp='用于统一记录升压药负荷；不同研究换算系数可能不同。'
    elif calc == 'infusion_rate' or calc == 'sedative_rate':
        weight=fval(data,'weight',70); amount=fval(data,'drug_amount',fval(data,'amount',0)); vol=fval(data,'total_volume',fval(data,'volume',50)); dose=fval(data,'target_dose',fval(data,'dose',1))
        conc=amount*1000/vol if vol>0 else float('nan')
        mlh=dose*weight*60/conc if conc>0 else float('nan')
        score=f"泵速 ≈ {r(mlh,2)} mL/h"; risk='请核对药物单位和浓度'
        details={'浓度 μg/mL（若amount为mg）':r(conc,2),'目标剂量':dose,'体重':weight}; interp='泵速 = 目标剂量 × 体重 × 60 / 浓度。若药物使用 mg/kg/h 或 μg/kg/h，请先确保 amount 单位一致。'
    elif calc == 'perfusion':
        mapv=fval(data,'map'); urine=fval(data,'urine'); lac=fval(data,'lactate'); crt=fval(data,'crt')
        flags=sum([mapv<65, urine<0.5, lac>=2, crt>3, sval(data,'skin')=='cool', sval(data,'mental')=='altered'])
        score=f"灌注异常线索 {flags}/6 项"; risk='灌注不足可能性高' if flags>=3 else ('需继续动态观察' if flags>=1 else '当前线索支持灌注相对充分')
        details={'MAP':mapv,'尿量':urine,'乳酸':lac,'CRT':crt}; interp='复苏终点应多指标综合，不宜只盯住MAP。'
    elif calc == 'fluid_resp':
        ppv=fval(data,'ppv'); svv=fval(data,'svv'); b=fval(data,'vti_before'); a=fval(data,'vti_after'); change=(a-b)/b*100 if b>0 else float('nan')
        valid=sval(data,'controlled_mv')=='yes' and sval(data,'arrhythmia')=='no'
        score=f"VTI/CO变化 {r(change,1)}%"; risk='提示容量反应性' if change>=10 else '未达到常用容量反应性阈值'
        details={'PPV':ppv,'SVV':svv,'PLR变化率':r(change,1),'PPV/SVV适用条件较好':valid}; interp='PLR诱导SV/CO或VTI增加≥10%左右常提示容量反应性；PPV/SVV需控制通气、规则心律等前提。'
    elif calc == 'co_converter':
        co=fval(data,'co',5); hr=fval(data,'hr',80); bsa=fval(data,'bsa',1.8)
        ci=co/bsa if bsa>0 else float('nan'); sv=co*1000/hr if hr>0 else float('nan'); svi=sv/bsa if bsa>0 else float('nan')
        score=f"CI {r(ci,2)} L/min/m²；SV {r(sv,1)} mL"; risk='CI偏低' if ci<2.2 else 'CI未低于常用低灌注阈值'
        details={'CO':co,'CI':r(ci,2),'SV':r(sv,1),'SVI':r(svi,1)}; interp='心排量指标必须结合血压、乳酸、氧输送和器官灌注解释。'
    elif calc == 'vti_change':
        b=fval(data,'vti_before'); a=fval(data,'vti_after'); change=(a-b)/b*100 if b>0 else float('nan')
        score=f"VTI变化 {r(change,1)}%"; risk='提示容量反应性' if change>=10 else '不支持明显容量反应性'
        details={'前VTI':b,'后VTI':a}; interp='PLR或小剂量补液后VTI上升通常代表每搏量增加。'
    elif calc == 'va_ecmo':
        flow=fval(data,'flow',3.5); wt=fval(data,'weight',70); bsa=fval(data,'bsa',1.8); mapv=fval(data,'map',65); lac=fval(data,'lactate',2); svo2=fval(data,'svo2',70)
        fkg=flow*1000/wt; findex=flow/bsa
        score=f"流量 {r(fkg,1)} mL/kg/min；流量指数 {r(findex,2)} L/min/m²"; risk='灌注指标仍需优化' if mapv<65 or lac>=2 or svo2<65 else '当前灌注指标相对可接受'
        details={'流量/体重':r(fkg,1),'流量指数':r(findex,2),'MAP':mapv,'乳酸':lac,'SvO2':svo2}; interp='ECMO流量是否足够需看氧输送、原生心功能、容量、血管阻力和乳酸趋势。'
    elif calc == 'ecmo_do2':
        hb=fval(data,'hb',10); sao2=fval(data,'sao2',98)/100; pao2=fval(data,'pao2',150); flow=fval(data,'flow',3.5)
        cao2=1.34*hb*sao2+0.003*pao2; do2=cao2*flow*10
        score=f"CaO₂ {r(cao2,2)} mL/dL；DO₂ {r(do2,0)} mL/min"; risk='氧输送偏低风险' if do2<500 else 'ECMO侧氧输送未明显偏低'
        details={'CaO2':r(cao2,2),'DO2':r(do2,0)}; interp='DO₂估算只代表ECMO侧氧输送，还需结合原生心输出量和全身耗氧。'
    elif calc == 'ecmo_gas':
        preo=fval(data,'pre_pao2'); posto=fval(data,'post_pao2'); prec=fval(data,'pre_paco2'); postc=fval(data,'post_paco2'); sweep=fval(data,'sweep')
        od=posto-preo; cd=prec-postc
        score=f"膜后-膜前PaO₂差 {r(od,1)}；CO₂下降 {r(cd,1)} mmHg"; risk='氧合器气体交换可能不足' if od<150 or cd<5 else '气体交换差值尚可'
        details={'氧分压差':r(od,1),'CO2下降':r(cd,1),'Sweep':sweep}; interp='需结合血流量、气体流量、膜肺使用时间、血栓/水汽和采血位置判断。'
    elif calc == 'harlequin':
        rspo=fval(data,'right_spo2'); lspo=fval(data,'lower_spo2'); lvef=fval(data,'lvef'); riskflag=(rspo<90 and lspo-rspo>=5 and sval(data,'femoral_va')=='yes')
        score='存在 Harlequin/North-South 风险' if riskflag else '未见典型上下半身氧合分离'
        risk='高风险：右上肢低氧且下肢氧合较好' if riskflag else '继续监测右桡动脉血气'
        details={'右上肢SpO2':rspo,'下肢SpO2':lspo,'LVEF':lvef}; interp='股动脉VA-ECMO且心脏射血恢复、肺氧合差时，应重点监测右桡动脉氧合。'
    elif calc == 'ecmo_weaning':
        lac=fval(data,'lactate'); vis=fval(data,'vis'); lvef=fval(data,'lvef'); vti=fval(data,'vti'); pp=fval(data,'pulse_pressure'); maplf=fval(data,'map_lowflow'); scv=fval(data,'scvo2_lowflow')
        ok=lac<2 and vis<=10 and lvef>=30 and vti>=10 and pp>=20 and maplf>=65 and scv>=60
        score='可考虑进入正式撤机/低流量评估流程' if ok else '暂不满足撤机初筛'
        risk='撤机初筛较好' if ok else '仍有循环或氧输送风险'
        details={'乳酸':lac,'VIS':vis,'LVEF':lvef,'VTI':vti,'脉压':pp,'低流量MAP':maplf,'低流量ScvO2':scv}; interp='撤机需团队评估和标准化低流量/夹闭流程，本工具只做初筛。'
    elif calc == 'iabp_record':
        mapv=fval(data,'map'); lac=fval(data,'lactate'); urine=fval(data,'urine'); vis=fval(data,'vis'); aug=fval(data,'aug_pressure')
        flags=sum([mapv>=65,lac<2,urine>=0.5,vis<=15,aug>90])
        score=f"支持效果线索 {flags}/5 项达标"; risk='支持效果相对可接受' if flags>=4 else '需复评容量、心功能、IABP时相和升级支持'
        details={'增强压':aug,'MAP':mapv,'乳酸':lac,'尿量':urine,'VIS':vis}; interp='IABP效果需结合舒张增强、左室卸载、冠脉灌注、乳酸和尿量趋势。'
    elif calc == 'lv_unloading':
        pcwp=fval(data,'pcwp'); pp=fval(data,'pulse_pressure'); flags=sum([pcwp>18,sval(data,'pulm_edema')=='yes',sval(data,'lv_distension')=='yes',pp<15,sval(data,'av_opening')=='minimal'])
        score=f"左心负荷异常线索 {flags}/5 项"; risk='需高度考虑左心减压/卸载策略' if flags>=3 else '暂未达到明显左心卸载不足模式'
        details={'PCWP':pcwp,'脉压':pp}; interp='VA-ECMO后左室扩张、肺水肿、主动脉瓣不开放提示左心卸载不足。'
    elif calc == 'crrt_dose':
        wt=fval(data,'weight'); eff=fval(data,'dialysate')+fval(data,'replacement')+fval(data,'net_uf'); dose=eff/wt if wt>0 else float('nan')
        score=f"Effluent dose {r(dose,1)} mL/kg/h"; risk='接近KDIGO常用递送剂量目标' if 20<=dose<=25 else ('剂量偏低' if dose<20 else '处方剂量偏高/需看适应证')
        details={'Effluent mL/h':eff,'体重':wt}; interp='CRRT常以effluent dose描述清除剂量，实际递送剂量会因停机而下降。'
    elif calc == 'crrt_delivered':
        wt=fval(data,'weight'); eff=fval(data,'prescribed_effluent'); planned=fval(data,'planned_hours'); down=fval(data,'downtime'); delivered=eff*max(planned-down,0)/planned/wt if planned>0 and wt>0 else float('nan')
        score=f"实际递送剂量 ≈ {r(delivered,1)} mL/kg/h"; risk='实际递送剂量达标' if delivered>=20 else '实际递送剂量可能不足'
        details={'有效治疗小时':max(planned-down,0),'处方effluent':eff}; interp='频繁停机时应提高处方剂量或减少中断，以保证实际递送剂量。'
    elif calc == 'citrate':
        bf=fval(data,'blood_flow'); target=fval(data,'target_citrate'); sol=fval(data,'citrate_solution'); post=fval(data,'post_filter_ica'); sysica=fval(data,'systemic_ica')
        rate=bf*60*target/sol if sol>0 else float('nan')
        score=f"枸橼酸液估算泵速 {r(rate,1)} mL/h"; risk='滤后iCa偏高，抗凝可能不足' if post>0.4 else ('体内iCa偏低，注意补钙/枸橼酸蓄积' if sysica<1.0 else '需按协议动态监测')
        details={'血流量':bf,'目标枸橼酸':target,'枸橼酸浓度':sol,'滤后iCa':post,'体内iCa':sysica}; interp='RCA需同时看滤后iCa、体内iCa、总钙/iCa比值、酸碱和肝功能。'
    elif calc == 'net_uf':
        cur=fval(data,'current_balance'); target=fval(data,'target_balance'); hours=fval(data,'hours'); rate=(cur-target)/hours if hours>0 else float('nan')
        score=f"建议净超滤目标 ≈ {r(rate,1)} mL/h"; risk='超滤目标较高，需关注血压和灌注' if rate>200 else '超滤目标相对温和'
        details={'当前平衡':cur,'目标平衡':target,'小时数':hours}; interp='净超滤应根据容量状态、血压、血管活性药、乳酸、尿量和耐受性动态调整。'
    elif calc == 'electrolyte_safety':
        cur=fval(data,'current'); target=fval(data,'target'); hours=fval(data,'hours'); rate=(target-cur)/hours*24 if hours>0 else float('nan')
        el=sval(data,'electrolyte')
        if el=='na': risk='钠纠正速度偏快风险' if abs(rate)>8 else '钠纠正速度在常用安全范围内'
        else: risk='钾纠正幅度较大，需频繁复查心电和血钾' if abs(target-cur)>=1.5 else '钾纠正幅度相对可控'
        score=f"预计24h变化 {r(rate,1)} mmol/L"; details={'当前':cur,'目标':target,'计划小时':hours}; interp='电解质纠正速度应按病程急慢性和症状个体化，重症患者需复查。'
    elif calc == 'oliguria':
        urine=fval(data,'urine'); mapv=fval(data,'map'); cvp=fval(data,'cvp'); fena=fval(data,'fena'); feurea=fval(data,'feurea')
        sug=[]
        if urine<0.5: sug.append('达到少尿标准')
        if mapv<65 or (fena<1 and feurea<35): sug.append('肾前性/灌注不足线索')
        if cvp>12: sug.append('静脉淤血/肾后负荷线索')
        if sval(data,'hydronephrosis')=='yes': sug.append('梗阻性因素')
        if sval(data,'cr_trend')=='rising' and fena>=2: sug.append('肾实质损伤可能')
        score='；'.join(sug) if sug else '暂无明确方向'
        risk='需尽快床旁超声和复查灌注指标' if urine<0.3 else '继续动态观察'
        details={'尿量':urine,'MAP':mapv,'CVP':cvp,'FeNa':fena,'FeUrea':feurea}; interp='少尿鉴别需同时排除低灌注、淤血、肾毒性、梗阻和导尿管问题。'
    elif calc == 'fluid_osm':
        # Volume-based CRRT replacement/dialysate fluid compounding estimator.
        # Common Chinese clinical stock solutions are used as defaults; local pharmacy specifications should be verified.
        final_ml=fval(data,'final_volume_ml',4000)
        if final_ml <= 0:
            final_ml = 1
        final_L = final_ml / 1000
        ns=fval(data,'ns_09_ml',0)
        water=fval(data,'sterile_water_ml',0)
        glu5=fval(data,'glucose_5_ml',0)
        nacl10=fval(data,'nacl_10_ml',0)
        nahco3=fval(data,'nahco3_5_ml',0)
        kcl=fval(data,'kcl_10_ml',0)
        caglu=fval(data,'ca_gluconate_10_ml',0)
        mgso4=fval(data,'mgso4_25_ml',0)
        lactate=fval(data,'sodium_lactate_ml',0)

        # mmol per mL assumptions
        ns_mmol_per_ml = 154/1000
        glucose5_mmol_per_ml = 50/180.156  # 5 g/dL = 50 mg/mL
        nacl10_mmol_per_ml = 100/58.44
        nahco3_5_mmol_per_ml = 50/84.01
        kcl10_mmol_per_ml = 100/74.55
        ca_gluconate10_mmol_per_ml = 100/448.39  # calcium gluconate monohydrate, approximate
        mgso4_25_mmol_per_ml = 250/246.47  # magnesium sulfate heptahydrate, approximate
        lactate_mmol_per_ml = 1.0  # approximate sodium lactate 11.2%

        na_mmol = ns*ns_mmol_per_ml + nacl10*nacl10_mmol_per_ml + nahco3*nahco3_5_mmol_per_ml + lactate*lactate_mmol_per_ml
        k_mmol = kcl*kcl10_mmol_per_ml
        ca_mmol = caglu*ca_gluconate10_mmol_per_ml
        mg_mmol = mgso4*mgso4_25_mmol_per_ml
        cl_mmol = ns*ns_mmol_per_ml + nacl10*nacl10_mmol_per_ml + kcl*kcl10_mmol_per_ml
        hco3_mmol = nahco3*nahco3_5_mmol_per_ml
        lactate_mmol = lactate*lactate_mmol_per_ml
        glucose_mmol = glu5*glucose5_mmol_per_ml
        sulfate_mmol = mgso4*mgso4_25_mmol_per_ml
        gluconate_mmol = caglu*ca_gluconate10_mmol_per_ml

        na=na_mmol/final_L; k=k_mmol/final_L; ca=ca_mmol/final_L; mg=mg_mmol/final_L
        cl=cl_mmol/final_L; hco3=hco3_mmol/final_L; lac=lactate_mmol/final_L; glucose=glucose_mmol/final_L
        # Estimated osmolarity: sum of osmotic particles after approximate dissociation.
        total_particles_mOsm = (
            ns*308/1000 +
            glu5*glucose5_mmol_per_ml +
            nacl10*nacl10_mmol_per_ml*2 +
            nahco3*nahco3_5_mmol_per_ml*2 +
            kcl*kcl10_mmol_per_ml*2 +
            caglu*ca_gluconate10_mmol_per_ml*2 +
            mgso4*mgso4_25_mmol_per_ml*2 +
            lactate*lactate_mmol_per_ml*2
        )
        osm = total_particles_mOsm/final_L
        cation_sum = na+k+2*ca+2*mg
        anion_sum = cl+hco3+lac+2*(sulfate_mmol/final_L)+(gluconate_mmol/final_L)
        volume_sum = ns+water+glu5+nacl10+nahco3+kcl+caglu+mgso4+lactate
        score=f"估算总渗透压 {r(osm,1)} mOsm/L；Na⁺ {r(na,1)} mmol/L；K⁺ {r(k,2)} mmol/L"
        if osm < 260:
            risk='估算渗透压偏低，需警惕低渗液导致血钠/渗透压下降。'
        elif osm > 330:
            risk='估算渗透压偏高，需警惕高渗负荷或电解质纠正过快。'
        else:
            risk='估算渗透压接近常用等渗范围，仍需结合患者血钠、血糖和CRRT剂量动态复核。'
        details={
            '最终定容总量 mL':r(final_ml,0),
            '输入组分体积合计 mL':r(volume_sum,0),
            'Na⁺ mmol/L':r(na,1),
            'K⁺ mmol/L':r(k,2),
            'Ca²⁺ mmol/L':r(ca,2),
            'Mg²⁺ mmol/L':r(mg,2),
            'Cl⁻ mmol/L':r(cl,1),
            'HCO₃⁻ mmol/L':r(hco3,1),
            '乳酸盐 mmol/L':r(lac,1),
            '葡萄糖 mmol/L':r(glucose,1),
            '估算总渗透压 mOsm/L':r(osm,1),
            '阳离子当量合计 mEq/L':r(cation_sum,1),
            '阴离子当量合计 mEq/L':r(anion_sum,1),
        }
        interp='该工具按加入各溶液的毫升数反推最终成品浓度和渗透压，适合床旁复核CRRT置换液/透析液配置。实际渗透压受药品规格、解离程度、混合体积变化和药剂科配置流程影响。'
    elif calc == 'dialysate_match':
        pna=fval(data,'patient_na'); fna=fval(data,'fluid_na'); pk=fval(data,'patient_k'); fk=fval(data,'fluid_k'); ph=fval(data,'patient_hco3'); fh=fval(data,'fluid_hco3')
        msgs=[]
        if abs(pna-fna)>10: msgs.append('Na梯度较大，需警惕纠钠过快')
        if pk>=5.5 and fk>=4: msgs.append('高钾患者液体K偏高，需复核')
        if ph<18 and fh>=32: msgs.append('酸中毒纠正可能较快，需监测pH/HCO3')
        score='；'.join(msgs) if msgs else '配置与患者电解质差异未见明显警报'
        risk='需复核CRRT液体配置' if msgs else '可按病情继续监测'
        details={'患者Na':pna,'液体Na':fna,'患者K':pk,'液体K':fk,'患者HCO3':ph,'液体缓冲碱':fh}; interp='严重低/高钠、极端K或酸碱紊乱时，CRRT液体配置会显著影响纠正速度。'
    elif calc == 'coverage':
        source=sval(data,'source'); mdro=sval(data,'mdro')
        targets={
          'pneumonia':'肺炎链球菌/流感嗜血杆菌；HAP/VAP需考虑铜绿假单胞菌、肠杆菌、MRSA风险',
          'abdomen':'肠杆菌、厌氧菌、肠球菌风险；重点是源控制',
          'urinary':'肠杆菌科、肠球菌；复杂尿路需考虑ESBL/铜绿风险',
          'catheter':'葡萄球菌、肠球菌、革兰阴性杆菌；必要时覆盖MRSA',
          'skin':'链球菌、金葡菌；坏死性软组织感染需覆盖厌氧菌和毒素抑制',
          'cns':'肺炎链球菌、脑膜炎奈瑟菌、李斯特菌/院内革兰阴性按场景',
          'unknown':'根据院内流行病学覆盖革兰阴性、革兰阳性，必要时考虑真菌'
        }
        score=targets.get(source,'需感染科会诊')
        risk='存在MDR风险，应结合本院药敏和既往定植/用药史扩大覆盖并及时降阶梯' if mdro=='high' else 'MDR风险低时避免不必要广谱覆盖'
        details={'感染部位':source,'MDR风险':mdro}; interp='经验治疗覆盖目标应在培养结果和临床反应出来后及时复评和降阶梯。'
    elif calc == 'renal_abx':
        crcl=fval(data,'crcl'); drug=sval(data,'drug')
        no_adjust={'linezolid','ceftriaxone'}
        score='通常不需按肾功能常规调整或调整较少' if drug in no_adjust else ('CrCl下降，通常需要肾功能剂量调整/延长间隔' if crcl<50 else 'CrCl较好，常规剂量可能可用')
        risk='必须查本院药学系统，尤其CRRT/ECMO/肥胖/严重感染时' ; details={'CrCl':crcl,'药物':drug}; interp='抗菌药剂量取决于感染严重度、MIC、PK/PD、CRRT模式和TDM。'
    elif calc == 'vanco':
        wt=fval(data,'weight'); crcl=fval(data,'crcl'); mic=fval(data,'mic'); auc=fval(data,'target_auc')
        load_low=20*wt; load_high=25*wt
        score=f"负荷剂量参考 {r(load_low/1000,2)}–{r(load_high/1000,2)} g"
        risk='需AUC/TDM监测，避免肾毒性' if crcl<60 else '建议AUC导向TDM'
        details={'目标AUC/MIC':r(auc/mic if mic>0 else float('nan'),1),'CrCl':crcl}; interp='严重MRSA感染通常采用AUC导向监测，简易剂量不能替代血药浓度。'
    elif calc == 'aminoglycoside':
        crcl=fval(data,'crcl'); drug=sval(data,'drug'); wt=fval(data,'weight')
        interval='q24h' if crcl>=60 else ('q36h' if crcl>=40 else ('q48h或更长' if crcl>=20 else '避免或TDM严密监测'))
        score=f"延长间隔方向：{interval}"; risk='需峰谷浓度/TDM和感染科/药师参与'
        details={'体重':wt,'CrCl':crcl,'药物':drug}; interp='氨基糖苷类肾毒性和耳毒性风险高，ICU患者PK变化大。'
    elif calc == 'candida':
        s=0
        if checked(data,'surgery'): s+=1
        if checked(data,'colonization'): s+=1
        if checked(data,'tpn'): s+=1
        if checked(data,'sepsis'): s+=2
        score=f"Candida score {s}"; risk='侵袭性念珠菌风险较高' if s>=3 else '风险较低或需结合培养/β-D葡聚糖/病情'
        details={'分数':s}; interp='Candida score用于非粒缺ICU患者风险提示，不等于诊断。'
    elif calc == 'pct_crp':
        pct0=fval(data,'pct0'); pct1=fval(data,'pct1'); crp0=fval(data,'crp0'); crp1=fval(data,'crp1'); days=fval(data,'days')
        pctchg=(pct0-pct1)/pct0*100 if pct0>0 else float('nan'); crpchg=(crp0-crp1)/crp0*100 if crp0>0 else float('nan')
        score=f"PCT下降 {r(pctchg,1)}%；CRP下降 {r(crpchg,1)}%"; risk='炎症指标下降趋势较好' if pctchg>=50 or crpchg>=30 else '下降不明显，需结合感染源控制和临床反应'
        details={'间隔天数':days,'PCT下降%':r(pctchg,1),'CRP下降%':r(crpchg,1)}; interp='PCT/CRP动态变化比单次数值更有价值，但不能单独决定停用抗菌药。'
    elif calc == 'heparin':
        wt=fval(data,'weight'); rate=fval(data,'rate'); aptt=fval(data,'aptt'); axa=fval(data,'anti_xa'); ukg=rate/wt if wt>0 else float('nan')
        score=f"UFH {r(ukg,1)} U/kg/h"; risk='抗Xa在常用治疗范围附近' if 0.3<=axa<=0.7 else '抗Xa不在常用治疗范围，需按本院方案调整'
        details={'APTT':aptt,'Anti-Xa':axa,'U/kg/h':r(ukg,1)}; interp='普通肝素监测受急性期反应、AT水平、试剂差异影响；抗Xa和APTT应结合本院目标范围。'
    elif calc == 'bleed_thromb':
        plt=fval(data,'plt'); inr=fval(data,'inr'); fib=fval(data,'fib'); d=fval(data,'dimer')
        bleed_flags=sum([plt<50,inr>1.5,fib<1.5,sval(data,'bleeding')=='yes'])
        throm_flags=sum([d>2,sval(data,'vte_risk')=='high'])
        score=f"出血线索 {bleed_flags}/4；血栓线索 {throm_flags}/2"; risk='出血与血栓风险并存，需个体化平衡' if bleed_flags and throm_flags else ('出血风险突出' if bleed_flags else '血栓风险需关注')
        details={'PLT':plt,'INR':inr,'FIB':fib,'D-dimer':d}; interp='ICU凝血异常常呈动态变化，抗凝/输血决策需结合出血部位和血栓风险。'
    elif calc == 'teg':
        R=fval(data,'r'); K=fval(data,'k'); angle=fval(data,'angle'); MA=fval(data,'ma'); ly=fval(data,'ly30')
        msgs=[]
        if R>10: msgs.append('凝血因子不足/肝素效应方向')
        if K>3 or angle<50: msgs.append('纤维蛋白原不足方向')
        if MA<50: msgs.append('血小板数量/功能不足方向')
        if ly>7.5: msgs.append('纤溶亢进方向')
        score='；'.join(msgs) if msgs else '未见明显TEG异常模式'
        risk='需结合出血情况和本院TEG/ROTEM参考范围'; details={'R/CT':R,'K/CFT':K,'α角':angle,'MA/MCF':MA,'LY30':ly}; interp='TEG/ROTEM不同设备参数不同，本工具只做方向性提示。'
    elif calc == 'transfusion':
        wt=fval(data,'weight'); hb=fval(data,'hb'); hbt=fval(data,'hb_target'); fib=fval(data,'fib'); fibt=fval(data,'fib_target'); plt=fval(data,'plt')
        rbc=max(0, math.ceil((hbt-hb)/10))
        fib_need=max(0,(fibt-fib)*wt*0.05)  # rough grams
        score=f"RBC约 {rbc} U；纤维蛋白原约 {r(fib_need,1)} g 方向"
        risk='活动性出血/手术需按MTP和输血科规范执行'
        details={'Hb':hb,'目标Hb':hbt,'FIB':fib,'目标FIB':fibt,'PLT':plt}; interp='估算非常粗略，具体输血需看出血速度、凝血图、TEG/ROTEM和本院规范。'
    elif calc == 'hit4t':
        s=sum(int(sval(data,k,0)) for k in ['thrombocytopenia','timing','thrombosis','other'])
        score=f"4Ts score {s}"; risk='高概率' if s>=6 else ('中等概率' if s>=4 else '低概率')
        details={'总分':s}; interp='低分对排除HIT较有价值；中高分需结合PF4抗体/功能实验和替代抗凝。'
    elif calc == 'dic_combined':
        plt=fval(data,'plt'); inr=fval(data,'pt_inr'); ptp=fval(data,'pt_prolong'); fib=fval(data,'fib'); marker=int(sval(data,'fibrin_marker','0')); sofa=fval(data,'sofa'); sirs=int(sval(data,'sirs','0'))
        sic=(2 if plt<100 else (1 if plt<150 else 0))+(2 if inr>1.4 else (1 if inr>1.2 else 0))+(2 if sofa>=2 else 0)
        isth=(2 if plt<50 else (1 if plt<100 else 0))+marker+(2 if ptp>=6 else (1 if ptp>=3 else 0))+(1 if fib<1 else 0)
        jaam=(3 if plt<80 else (1 if plt<120 else 0))+marker+(1 if ptp>=3 else 0)+sirs
        score=f"SIC {sic}；ISTH {isth}；JAAM {jaam}"
        risk='符合或接近DIC/SIC高风险阈值，需动态复评' if sic>=4 or isth>=5 or jaam>=4 else '暂未达到常用阳性阈值'
        details={'SIC':sic,'ISTH':isth,'JAAM':jaam}; interp='不同DIC评分适用人群和阈值不同；建议同一患者动态趋势观察。'
    elif calc == 'energy':
        sex=sval(data,'sex'); age=fval(data,'age'); h=fval(data,'height'); wt=fval(data,'weight'); stress=fval(data,'stress')
        bmr=66.47+13.75*wt+5.003*h-6.755*age if sex=='male' else 655.1+9.563*wt+1.85*h-4.676*age
        hb=bmr*stress; simple_low=25*wt; simple_high=30*wt
        score=f"HB×应激 {r(hb,0)} kcal/day；25–30 kcal/kg {r(simple_low,0)}–{r(simple_high,0)}"
        risk='早期危重症常需渐进达标，避免过度喂养'; details={'BMR':r(bmr,0),'HB调整':r(hb,0),'25kcal/kg':r(simple_low,0),'30kcal/kg':r(simple_high,0)}; interp='间接测热优先；无条件时可用体重公式或预测公式估算。'
    elif calc == 'protein':
        wt=fval(data,'weight'); cond=sval(data,'condition')
        ranges={'general':(1.2,2.0),'crrt':(1.5,2.5),'trauma_burn':(1.5,2.5),'obese':(2.0,2.5)}[cond]
        score=f"蛋白目标 {r(wt*ranges[0],0)}–{r(wt*ranges[1],0)} g/day"; risk='肾/肝功能、CRRT、烧伤创伤状态会显著改变目标'
        details={'下限 g/kg':ranges[0],'上限 g/kg':ranges[1]}; interp='蛋白目标应结合营养风险、氮平衡、肾替代治疗和耐受性。'
    elif calc == 'enteral_rate':
        kcal=fval(data,'target_kcal'); den=fval(data,'density'); hours=fval(data,'hours'); rate=kcal/den/hours if den>0 and hours>0 else float('nan')
        score=f"肠内营养速度 {r(rate,1)} mL/h"; risk='需结合胃肠耐受、升压药剂量和误吸风险'
        details={'目标热卡':kcal,'密度':den,'输注小时':hours}; interp='实际速度应渐进增加，并考虑冲管、暂停和蛋白补充。'
    elif calc == 'npcn':
        kcal=fval(data,'nonprotein_kcal'); protein=fval(data,'protein'); n=protein/6.25 if protein>0 else float('nan'); ratio=kcal/n if n>0 else float('nan')
        score=f"NPC:N ≈ {r(ratio,0)}:1"; risk='比值过高提示蛋白相对不足，比值过低需看代谢状态'
        details={'氮摄入g':r(n,1),'非蛋白热氮比':r(ratio,0)}; interp='NPC:N可用于评估热卡和蛋白比例，ICU通常更关注足够蛋白和避免过度热卡。'
    elif calc == 'nitrogen':
        protein=fval(data,'protein'); uun=fval(data,'uun'); non=fval(data,'nonurinary'); bal=protein/6.25-(uun+non)
        score=f"氮平衡 {r(bal,1)} g/day"; risk='负氮平衡' if bal<0 else '氮平衡非负'
        details={'氮摄入':r(protein/6.25,1),'氮排出估算':r(uun+non,1)}; interp='发热、创伤、烧伤、CRRT会增加氮丢失，UUN采集误差也会影响结果。'
    elif calc == 'insulin_helper':
        glu=fval(data,'glucose'); lo=fval(data,'target_low'); hi=fval(data,'target_high'); rate=fval(data,'current_rate'); trend=sval(data,'trend')
        if glu<lo: msg='低于目标，需按低血糖/降速流程处理'
        elif glu>hi and trend=='rising': msg='高于目标且上升，可考虑按本院方案上调'
        elif glu>hi: msg='高于目标，需复查趋势和营养输入'
        else: msg='位于目标范围，维持并监测'
        score=msg; risk='不生成医嘱，仅提示方向'
        details={'血糖':glu,'当前泵速':rate,'趋势':trend}; interp='ICU控糖以避免低血糖和大幅波动为核心，调泵需遵循本院协议。'
    elif calc == 'refeeding':
        bmi=fval(data,'bmi'); days=fval(data,'fasting_days'); wl=fval(data,'weight_loss'); flags=sum([bmi<18.5,days>=5,wl>=10,sval(data,'low_electrolytes')=='yes',sval(data,'risk_history')=='yes'])
        score=f"再喂养风险线索 {flags}/5"; risk='高风险，需低速起始并补充/监测电解质和维生素' if flags>=2 else '风险较低但仍需监测'
        details={'BMI':bmi,'禁食天数':days,'体重下降%':wl}; interp='再喂养风险患者应严密监测磷、钾、镁和容量负荷。'
    elif calc == 'camicu':
        if sval(data,'rass')=='coma':
            score='RASS -4/-5：暂不进行谵妄评估'; risk='先处理昏迷原因'
        else:
            positive=sval(data,'acute')=='yes' and sval(data,'attention')=='yes' and (sval(data,'thinking')=='yes' or sval(data,'loc')=='yes')
            score='CAM-ICU 阳性' if positive else 'CAM-ICU 阴性'
            risk='提示谵妄' if positive else '本次筛查未提示谵妄'
        details={}; interp='CAM-ICU阳性需寻找可逆诱因，如感染、低氧、药物、睡眠剥夺、疼痛等。'
    elif calc == 'icdsc':
        s=sum(1 for f in tool['fields'] if checked(data,f['name']))
        score=f"ICDSC {s}/8"; risk='≥4分提示谵妄' if s>=4 else ('1–3分提示亚综合征谵妄风险' if s>=1 else '未提示谵妄')
        details={'ICDSC':s}; interp='ICDSC适合连续观察谵妄症状波动。'
    elif calc == 'sedation_target':
        deep = any(sval(data,k)=='yes' for k in ['ards','tbi'])
        if deep: score='可考虑较深镇静目标（如RASS -3至-5），并每日复评'
        elif sval(data,'mv')=='yes' or sval(data,'ecmo')=='yes': score='优先浅镇静目标（如RASS -2至0），除非有特殊适应证'
        else: score='通常以舒适、可唤醒、避免谵妄为目标'
        risk='镇静目标应每日设定和复评'; details={k:sval(data,k) for k in ['mv','ards','ecmo','tbi','shock']}; interp='PADIS强调镇痛优先、浅镇静、谵妄监测和早期活动。'
    elif calc == 'opioid_eq':
        morph=fval(data,'morphine_iv'); fent=fval(data,'fentanyl_mcg_h')*24/100; hyd=fval(data,'hydromorphone_iv')*5; oxy=fval(data,'oxycodone_po')/3
        total=morph+fent+hyd+oxy
        score=f"IV morphine equivalent 约 {r(total,1)} mg/day"; risk='仅供粗略换算，转换时需不完全交叉耐受减量'
        details={'吗啡':morph,'芬太尼折算':r(fent,1),'氢吗啡酮折算':r(hyd,1),'羟考酮折算':r(oxy,1)}; interp='阿片换算表差异较大，肝肾功能、镇痛目标和耐受性会影响剂量。'
    elif calc == 'winter':
        h=fval(data,'hco3'); p=fval(data,'paco2'); exp=1.5*h+8; lo=exp-2; hi=exp+2
        score=f"预期PaCO₂ {r(lo,1)}–{r(hi,1)} mmHg"; risk='合并呼吸性酸/碱中毒可能' if p<lo or p>hi else '呼吸代偿大致合适'
        details={'实测PaCO2':p,'预期中值':r(exp,1)}; interp='Winter公式用于代谢性酸中毒的呼吸代偿判断。'
    elif calc == 'met_alk':
        h=fval(data,'hco3'); p=fval(data,'paco2'); exp=0.7*(h-24)+40; lo=exp-5; hi=exp+5
        score=f"预期PaCO₂ {r(lo,1)}–{r(hi,1)} mmHg"; risk='合并呼吸性问题可能' if p<lo or p>hi else '代偿大致合适'
        details={'实测PaCO2':p,'预期中值':r(exp,1)}; interp='代谢性碱中毒代偿受低氧、通气驱动和肺病影响。'
    elif calc == 'resp_comp':
        p=fval(data,'paco2'); h=fval(data,'hco3'); typ=sval(data,'type')
        delta=p-40
        if typ=='acidosis':
            acute=24+delta/10; chronic=24+3.5*delta/10
        else:
            acute=24+2*delta/10; chronic=24+5*delta/10
        score=f"急性预期HCO₃≈{r(acute,1)}；慢性≈{r(chronic,1)} mmol/L"
        risk='若实测明显偏离，提示混合性酸碱障碍'
        details={'实测HCO3':h,'PaCO2':p}; interp='呼吸性酸/碱中毒代偿需按急性或慢性病程解释。'
    elif calc == 'sid':
        na=fval(data,'na'); k=fval(data,'k'); ca=fval(data,'ca'); mg=fval(data,'mg'); cl=fval(data,'cl'); lac=fval(data,'lactate')
        sid=na+k+2*ca+2*mg-cl-lac
        score=f"Apparent SID ≈ {r(sid,1)} mmol/L"; risk='SID降低倾向代谢性酸中毒' if sid<38 else 'SID未明显降低'
        details={'SIDa':r(sid,1)}; interp='Stewart方法把强离子差作为酸碱状态的重要决定因素。'
    elif calc == 'corrected_ca':
        ca=fval(data,'ca'); alb=fval(data,'albumin'); corr=ca+0.02*(40-alb)
        score=f"校正钙 {r(corr,2)} mmol/L"; risk='白蛋白低时总钙低估离子钙风险'
        details={'总钙':ca,'白蛋白':alb}; interp='危重患者最好直接测离子钙，校正公式仅供参考。'
    elif calc == 'hypona':
        so=fval(data,'serum_osm'); uo=fval(data,'urine_osm'); una=fval(data,'urine_na'); vol=sval(data,'volume')
        if so>=280: msg='非低渗性低钠：考虑高糖、甘露醇、假性低钠等'
        elif uo<100: msg='低渗低钠且尿稀释：考虑摄水过多/低溶质摄入'
        elif una<30 and vol=='low': msg='低容量性低钠可能'
        elif vol=='eu' and una>=30: msg='SIADH/内分泌/药物等方向'
        elif vol=='high': msg='高容量性低钠：心衰/肝硬化/肾衰方向'
        else: msg='需结合容量状态和内分泌检查'
        score=msg; risk='症状性或重度低钠需紧急处理并严控纠正速度'
        details={'血浆渗透压':so,'尿渗':uo,'尿钠':una,'容量':vol}; interp='低钠首先区分低渗/非低渗，再看尿渗、尿钠和容量状态。'
    elif calc == 'hyperna':
        na=fval(data,'na'); target=fval(data,'target_na'); wt=fval(data,'weight'); factor=float(sval(data,'tbw_factor','0.6')); deficit=factor*wt*(na/target-1)
        score=f"自由水缺失 ≈ {r(deficit,2)} L"; risk='慢性高钠需避免纠正过快'
        details={'TBW系数':factor,'目标Na':target}; interp='补水计划需加上持续丢失，并动态复查钠。'
    elif calc == 'bicarb_deficit':
        wt=fval(data,'weight'); h=fval(data,'hco3'); target=fval(data,'target'); dist=fval(data,'distribution'); need=dist*wt*(target-h)
        score=f"HCO₃⁻ 缺口 ≈ {r(need,0)} mmol"; risk='碳酸氢钠可增加CO₂负荷和钠负荷，需谨慎'
        details={'分布系数':dist,'当前HCO3':h,'目标':target}; interp='严重酸中毒处理应优先病因、通气和灌注，碳酸氢钠为特定场景辅助。'
    elif calc == 'ag_albumin':
        na=fval(data,'na'); cl=fval(data,'cl'); h=fval(data,'hco3'); alb=fval(data,'albumin'); ag=na-cl-h; corr=ag+2.5*(4-alb)
        score=f"AG {r(ag,1)}；白蛋白校正AG {r(corr,1)}"; risk='校正AG升高提示高AG代谢性酸中毒'
        details={'AG':r(ag,1),'校正AG':r(corr,1)}; interp='低白蛋白会掩盖阴离子间隙升高。'
    else:
        score='该工具已记录输入，计算逻辑待扩展'; risk=''; interp='请结合临床判断。'
    return {'score':score,'risk_level':risk,'interpretation':interp,'details':details,'caution':caution}

@app.get('/health')
async def health():
    return PlainTextResponse('ok')

@app.get('/', response_class=HTMLResponse)
async def index(request: Request):
    grouped=[]
    for c in CATEGORIES:
        grouped.append((c,[t for t in TOOLS if t['category']==c]))
    return templates.TemplateResponse('index.html', {'request':request,'title':APP_TITLE,'department':DEPARTMENT,'version':VERSION,'groups':grouped,'tool_count':len(TOOLS)})

@app.get('/about', response_class=HTMLResponse)
async def about(request: Request):
    return templates.TemplateResponse('about.html', {'request':request,'title':APP_TITLE,'department':DEPARTMENT,'version':VERSION})

@app.get('/tools/{slug}', response_class=HTMLResponse)
async def tool_get(request: Request, slug: str):
    if slug not in TOOLS_BY_SLUG:
        return templates.TemplateResponse('404.html', {'request':request,'title':APP_TITLE,'department':DEPARTMENT}, status_code=404)
    t=TOOLS_BY_SLUG[slug]
    defaults={f['name']: f.get('default','') for f in t['fields']}
    return templates.TemplateResponse('tool.html', {'request':request,'title':APP_TITLE,'department':DEPARTMENT,'tool':t,'formdata':defaults,'result':None,'error':None})

@app.post('/tools/{slug}', response_class=HTMLResponse)
async def tool_post(request: Request, slug: str):
    if slug not in TOOLS_BY_SLUG:
        return templates.TemplateResponse('404.html', {'request':request,'title':APP_TITLE,'department':DEPARTMENT}, status_code=404)
    t=TOOLS_BY_SLUG[slug]
    form = await request.form()
    data = dict(form)
    try:
        result=calculate(slug,data)
        err=None
    except Exception as e:
        result=None; err=f'计算失败：{e}'
    return templates.TemplateResponse('tool.html', {'request':request,'title':APP_TITLE,'department':DEPARTMENT,'tool':t,'formdata':data,'result':result,'error':err})
