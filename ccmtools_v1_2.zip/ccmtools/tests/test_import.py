from app.main import TOOLS
assert len(TOOLS) >= 70
