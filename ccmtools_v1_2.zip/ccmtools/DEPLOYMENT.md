# 部署说明：tools.shccm.icu

本项目设计为独立服务，不影响现有 XBJ-SIC 随机化系统：

- XBJ-SIC：`127.0.0.1:8000`，服务 `xbj_sic.service`
- 现有计算器：`127.0.0.1:8010`，服务 `cardiac-calc.service`
- 本工具箱：`127.0.0.1:8020`，服务 `ccmtools.service`

## 1. DNS

在阿里云 DNS 添加：

```text
A 记录
tools.shccm.icu -> 101.133.166.107
```

## 2. 从 GitHub 部署

```bash
cd /opt

git clone https://github.com/drliuxb/ccmtools.git /opt/ccmtools
cd /opt/ccmtools

python3 -m venv venv
./venv/bin/pip install --upgrade pip
./venv/bin/pip install -r requirements.txt

cp deploy/ccmtools.env /etc/ccmtools.env
cp deploy/ccmtools.service /etc/systemd/system/ccmtools.service

chown -R www-data:www-data /opt/ccmtools
chmod -R 755 /opt/ccmtools

systemctl daemon-reload
systemctl enable ccmtools
systemctl start ccmtools
systemctl status ccmtools --no-pager

curl -s http://127.0.0.1:8020 | head
```

## 3. Nginx HTTP 配置

```bash
cp /opt/ccmtools/deploy/tools.shccm.icu.http.nginx /etc/nginx/sites-available/tools.shccm.icu
ln -sf /etc/nginx/sites-available/tools.shccm.icu /etc/nginx/sites-enabled/tools.shccm.icu
mkdir -p /var/www/letsencrypt/.well-known/acme-challenge
chown -R www-data:www-data /var/www/letsencrypt
nginx -t
systemctl reload nginx
curl -s http://tools.shccm.icu | head
```

## 4. HTTPS 证书

优先尝试 webroot：

```bash
certbot certonly --webroot -w /var/www/letsencrypt -d tools.shccm.icu
```

如果 HTTP-01 失败，可用 DNS-01 手动验证：

```bash
certbot certonly --manual --preferred-challenges dns -d tools.shccm.icu
```

然后到阿里云 DNS 添加 TXT：

```text
主机记录: _acme-challenge.tools
记录类型: TXT
记录值: certbot 给出的 value
```

## 5. 写入 HTTPS Nginx 配置

证书成功后：

```bash
cp /opt/ccmtools/deploy/tools.shccm.icu.ssl.nginx /etc/nginx/sites-available/tools.shccm.icu
nginx -t
systemctl reload nginx
curl -s https://tools.shccm.icu | head
```

## 6. 验收

```bash
systemctl is-active ccmtools
systemctl is-enabled ccmtools
systemctl is-active xbj_sic
systemctl is-active cardiac-calc
ss -tulpn | grep -E '80|443|8000|8010|8020'
nginx -t
curl -s https://tools.shccm.icu | grep "东方医院重症医学工具箱" | head
curl -s https://tools.shccm.icu/tools/replacement-fluid-osmolality | grep -E "<h1>|置换液" | head
curl -k -s https://xbj-sic.shccm.icu | head
```

## 7. 后续 GitHub 更新

```bash
cd /opt/ccmtools
git pull
./venv/bin/pip install -r requirements.txt
systemctl restart ccmtools
systemctl status ccmtools --no-pager
```

## 8. 回滚

保留每次更新前备份：

```bash
tar -czf /root/ccmtools_backup_$(date +%F_%H%M).tar.gz /opt/ccmtools /etc/nginx/sites-available/tools.shccm.icu /etc/systemd/system/ccmtools.service /etc/ccmtools.env
```
